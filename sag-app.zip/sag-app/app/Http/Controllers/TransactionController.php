<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

use PDF;
use Validator;
use Carbon\Carbon;

class TransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Http\Response|\Illuminate\View\View
     */
    public function index()
    {
        $transaction = Transaction::with(['food','user'])->paginate(10);

        return view('transactions.index', [
            'transaction' => $transaction
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Transaction  $transaction
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Http\Response|\Illuminate\View\View
     */
    public function show(Transaction $transaction)
    {
        return view('transactions.detail',[
            'item' => $transaction
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Transaction  $transaction
     * @return \Illuminate\Http\Response
     */
    public function edit(Transaction $transaction)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Transaction  $transaction
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Transaction $transaction)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Transaction  $transaction
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(Transaction $transaction)
    {
        $transaction->delete();

        return redirect()->route('transactions.index');
    }

    /**
     * @param Request $request
     * @param $id
     * @param $status
     * @return \Illuminate\Http\RedirectResponse
     */
    public function changeStatus(Request $request, $id, $status)
    {
        $transaction = Transaction::findOrFail($id);

        $transaction->status = $status;
        $transaction->save();

        return redirect()->route('transactions.show', $id);
    }

    public function report(Request $request)
    {
        return view('transactions.report',[]);
    }

    public function generateReport(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "start_date" => "required",
            "end_date" => "required"
        ],
        [
            "start_date.required" => "Tanggal mulai harus diisi.",
            "end_date.required" => "Tanggal akhir harus diisi."
        ]);

        if($validator->fails()){
            return redirect()->back()->withInput()->withErrors($validator);
        }

        $startDate = Carbon::parse($request->start_date)->format("Y-m-d 00:00:00");
        $endDate = Carbon::parse($request->end_date)->format("Y-m-d 23:59:59");

        $getReport = Transaction::with('food')
                                    ->select('transactions.food_id', 'food.name', DB::raw('SUM(transactions.quantity) AS total_qty'), DB::raw('SUM(transactions.total) AS total_penjualan'))
                                    ->join('food', 'transactions.food_id', '=', 'food.id')
                                    ->whereBetween('transactions.updated_at', [$startDate, $endDate])
                                    ->where('transactions.status', '!=', 'CANCELLED')
                                    ->groupBy('transactions.food_id', 'food.name')
                                    ->orderBy('food.name', 'ASC')            
                                    ->get();

        $data['item'] = $getReport;
        $data['start_date'] = $startDate;
        $data['end_date'] = $endDate;

        $pdf = PDF::loadView('reports.transaction', $data)->setPaper('a4', 'landscape');

        return $pdf->download('report.pdf');
    }
}
