<div class="hidden sm:block">
    <div class="py-8">
        <div class="border-t border-gray-200"></div>
    </div>
</div>
<?php /**PATH C:\Users\hp\brokat_aplikasi\backend-master\resources\views/vendor/jetstream/components/section-border.blade.php ENDPATH**/ ?>