<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <title>Laporan Transaksi</title>

        <!-- Tell the browser to be responsive to screen width -->
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <style>
            .table-header {
                width: auto;
                margin-left: auto;
                margin-right: auto;
            }
            .table-fill {
                width: auto;
                margin-left: auto;
                margin-right: auto;
                border: 1px solid black;
                border-collapse: collapse;
            }
            .header {
                width: auto;
                text-align: center;
                padding: 15px;
                border: 1px solid black;
                border-collapse: collapse;
                font-weight: bold;
            }
            .td-header {
                width: auto;
                padding: 5px;
            }
            .td-fill {
                width: auto;
                padding: 5px;
                border: 1px solid black;
                border-collapse: collapse;
            }
        </style>
    </head>
    <body>
        <table class="table-header">
            <tr>
                <td style="text-align: center;vertical-align: text-top;" class="td-header"><b>LAPORAN TRANSAKSI</b></td>
            </tr>
            <tr>
                <td style="text-align: center;vertical-align: text-top;" class="td-header"><b>Tanggal : {{ Carbon\Carbon::parse($start_date)->format('j F') }} - {{ Carbon\Carbon::parse($end_date)->format('j F Y') }} </b></td>
            </tr>
        </table>
        <br>
        <table class="table-fill">
            <tr>
                <td class="header">No</td>
                <td class="header">Nama Barang</td>
                <td class="header">Total Qty</td>
                <td class="header">Total Harga</td>
            </tr>

            @php 
                $i=1;
                $total = 0; 
            @endphp
            @foreach($item as $kData => $vData)
                <tr>
                    <td style="text-align: center;vertical-align: text-top;" class="td-fill">{{ $i++ }}</td>
                    <td style="text-align: center;vertical-align: text-top;" class="td-fill">{{ ucwords($vData->name) }}</td>
                    <td style="text-align: center;vertical-align: text-top;" class="td-fill">{{ number_format($vData->total_qty, 0) }}</td>
                    <td style="text-align: right;vertical-align: text-top;" class="td-fill">{{ number_format($vData->total_penjualan, 0) }}</td>
                </tr>

                @php
                    $total = $total + (int)$vData->total_penjualan;
                @endphp
            @endforeach
            <tr>
                <td colspan="3" style="text-align: center;font-weight: bold;" class="td-fill">Jumlah</td>
                <td style="text-align: right" class="td-fill"><b>{{ number_format($total, 0) }}<b></td>
            </tr>
        </table>
    </body>
</html>